# TakeHomeTech
Implentation of LC data processing for Waters Acquity data
